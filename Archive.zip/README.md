# [mariarabelero.github.io](https://mariarabelero.github.io/)

## Inspiration

mariarabelero.github.io is inspired by
- [Mobile HTML5 Boilerplate](https://html5boilerplate.com/mobile/).
- Yeoman's [generator-webapp](https://github.com/yeoman/generator-webapp).
- [Beautiful Creatures](http://www.dafont.com/es/beautiful-creatures.font) Font.
- [Full Page](https://github.com/alvarotrigo/fullPage.js) script.
